package com.statusbar.monitor.service

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.SuperscriptSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.statusbar.monitor.data.Prefs
import com.statusbar.monitor.ui.MainActivity

class MonitorService : Service() {

    companion object {
        const val ACTION_SETTINGS_CHANGED = "com.statusbar.monitor.SETTINGS_CHANGED"
        const val ACTION_STOP             = "com.statusbar.monitor.STOP"
        private const val CHANNEL_ID      = "sbm_channel"
        private const val ID_FG           = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var nm: NotificationManager

    private var overlayView: LinearLayout? = null

    // 数据
    @Volatile private var tempC    = Float.NaN
    @Volatile private var currentA = Float.NaN   // 真实安培值
    @Volatile private var memPct   = 0
    @Volatile private var downMBs  = 0f

    private var lastRx    = -1L
    private var lastNetMs = -1L

    private val handler = Handler(Looper.getMainLooper())
    private val netRunnable = object : Runnable {
        override fun run() {
            pollNet()
            updateOverlay()
            handler.postDelayed(this, Prefs.updateIntervalMs(this@MonitorService).toLong())
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> onBattery(intent)
                Intent.ACTION_SCREEN_ON  -> startNet()
                Intent.ACTION_SCREEN_OFF -> stopNet()
            }
        }
    }

    // ── 生命周期 ──────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        createChannel()
        startForeground(ID_FG, buildFgNotification())
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(receiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { cleanup(); stopSelf(); return START_NOT_STICKY }
            ACTION_SETTINGS_CHANGED -> { rebuildOverlay(); return START_STICKY }
        }
        rebuildOverlay()
        startNet()
        return START_STICKY
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    // ── 悬浮窗构建 ────────────────────────────────

    private fun rebuildOverlay() {
        removeOverlay()
        if (!Prefs.isEnabled(this)) return

        val sp = Prefs.textSizeSp(this).toFloat()

        // 外层容器：透明背景，横向排列
        val container = LinearLayout(this).apply {
            orientation  = LinearLayout.HORIZONTAL
            setPadding(dpToPx(4), dpToPx(1), dpToPx(4), dpToPx(1))
            setBackgroundColor(Color.TRANSPARENT)
            gravity = Gravity.CENTER_VERTICAL
        }

        // 创建一个带「大数字+右上叠单位」格式的 TextView
        fun addMetric(value: String, unit: String) {
            // 分隔点（不是第一个才加）
            if (container.childCount > 0) {
                container.addView(TextView(this).apply {
                    text = " · "
                    setTextColor(0xCCFFFFFF.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                    typeface = Typeface.DEFAULT_BOLD
                })
            }
            container.addView(TextView(this).apply {
                text = buildStackedText(value, unit, sp)
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                typeface = Typeface.DEFAULT_BOLD
                // 文字阴影，增强可读性（替代背景色）
                setShadowLayer(3f, 1f, 1f, 0xCC000000.toInt())
            })
        }

        if (Prefs.showTemp(this) && !tempC.isNaN()) {
            val (v, u) = formatTemp()
            addMetric(v, u)
        }
        if (Prefs.showCurrent(this)) {
            val (v, u) = formatCurrent()
            if (v.isNotEmpty()) addMetric(v, u)
        }
        if (Prefs.showMemory(this)) {
            addMetric("$memPct", "%")
        }
        if (Prefs.showNetDown(this)) {
            val (v, u) = formatNet()
            addMetric(v, u)
        }

        // 如果还没数据，加个占位避免空布局
        if (container.childCount == 0) {
            container.addView(TextView(this).apply {
                text = "…"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                setShadowLayer(3f, 1f, 1f, 0xCC000000.toInt())
            })
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.overlayX(this@MonitorService)
            y = Prefs.overlayY(this@MonitorService)
        }

        var initX = 0; var initY = 0
        var touchX = 0f; var touchY = 0f
        container.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x; initY = params.y
                    touchX = ev.rawX; touchY = ev.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (initX + (ev.rawX - touchX)).toInt()
                    params.y = (initY + (ev.rawY - touchY)).toInt()
                    wm.updateViewLayout(container, params); true
                }
                MotionEvent.ACTION_UP -> {
                    Prefs.set(this, Prefs.KEY_OVERLAY_X, params.x)
                    Prefs.set(this, Prefs.KEY_OVERLAY_Y, params.y); true
                }
                else -> false
            }
        }

        wm.addView(container, params)
        overlayView = container
    }

    /**
     * 构建「大数字 + 右上角叠小单位」SpannableString
     * 效果：value 正常大小，unit 缩小到 55% 并上标
     */
    private fun buildStackedText(value: String, unit: String, baseSp: Float): SpannableStringBuilder {
        val sb = SpannableStringBuilder(value).append(unit)
        val start = value.length
        val end   = sb.length
        // 上标
        sb.setSpan(SuperscriptSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        // 缩小到 55%
        sb.setSpan(RelativeSizeSpan(0.55f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun removeOverlay() {
        overlayView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlayView = null
    }

    // ── 数据更新 ──────────────────────────────────

    private fun onBattery(intent: Intent) {
        val rawT = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (rawT != Int.MIN_VALUE) tempC = rawT / 10f

        val bm  = getSystemService(BATTERY_SERVICE) as BatteryManager
        val µA  = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // 部分设备充电空闲时返回极小值（< 50mA），视为0
        currentA = if (µA != Int.MIN_VALUE) µA / 1_000_000f else Float.NaN

        memPct = getMemPct()
        handler.post { updateOverlay() }
    }

    private fun pollNet() {
        val rx  = TrafficStats.getTotalRxBytes()
        val now = System.currentTimeMillis()
        if (rx == TrafficStats.UNSUPPORTED.toLong()) return
        if (lastRx >= 0 && lastNetMs > 0) {
            val dt  = (now - lastNetMs).coerceAtLeast(1L)
            val bps = ((rx - lastRx) * 1000L / dt).coerceAtLeast(0L)
            downMBs = bps / 1_000_000f
        }
        lastRx = rx; lastNetMs = now
    }

    private fun updateOverlay() {
        // 数据变化就重建（保持 TextView 数量和内容同步）
        rebuildOverlay()
    }

    // ── 格式化 ────────────────────────────────────

    /** 返回 <数值字符串, 单位字符串> */
    private fun formatTemp(): Pair<String, String> {
        if (tempC.isNaN()) return Pair("--", "°")
        return if (Prefs.useFahrenheit(this))
            Pair("%.0f".format(tempC * 9 / 5 + 32), "°F")
        else
            Pair("%.0f".format(tempC), "°C")
    }

    /**
     * 电流：过滤掉充电空闲时几乎为0的噪声（< 0.05A）
     * 返回空字符串表示不显示
     */
    private fun formatCurrent(): Pair<String, String> {
        if (currentA.isNaN()) return Pair("", "")
        val abs = Math.abs(currentA)
        if (abs < 0.05f) return Pair("0", "A")    // 空闲/待机
        val sign = if (currentA > 0) "+" else "-"
        // 去掉多余小数：如 1.20 → 1.2，1.00 → 1
        val formatted = if (abs % 1.0f == 0f) "%.0f".format(abs)
                        else "%.2f".format(abs).trimEnd('0')
        return Pair("$sign$formatted", "A")
    }

    private fun formatNet(): Pair<String, String> {
        return if (downMBs >= 1f)
            Pair("%.1f".format(downMBs), "M/s")
        else
            Pair("%.0f".format(downMBs * 1000), "K/s")
    }

    private fun getMemPct(): Int {
        val am   = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        if (info.totalMem == 0L) return 0
        return ((info.totalMem - info.availMem) * 100L / info.totalMem).toInt()
    }

    // ── 工具 ──────────────────────────────────────

    private fun startNet() {
        handler.removeCallbacks(netRunnable)
        if (Prefs.showNetDown(this)) handler.post(netRunnable)
    }
    private fun stopNet() { handler.removeCallbacks(netRunnable) }

    private fun dpToPx(dp: Int) = (dp * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "监控服务",
            NotificationManager.IMPORTANCE_MIN).apply {
            setShowBadge(false); setSound(null, null)
        }
        nm.createNotificationChannel(ch)
    }

    private fun buildFgNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("状态栏监控运行中")
            .setContentText("悬浮窗显示中")
            .setOngoing(true).setContentIntent(pi).build()
    }

    private fun cleanup() {
        stopNet(); removeOverlay()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
    }
}
