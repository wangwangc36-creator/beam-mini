package com.statusbar.monitor.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.statusbar.monitor.data.Prefs
import com.statusbar.monitor.databinding.ActivityMainBinding
import com.statusbar.monitor.service.MonitorService

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    private val overlayLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) startMonitor()
        else Toast.makeText(this, "需要「显示在其他应用上层」权限", Toast.LENGTH_LONG).show()
    }

    private val notifLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startMonitor() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        restoreUi()
        setupListeners()
        if (Prefs.isEnabled(this)) checkPermissionsAndStart()
    }

    private fun restoreUi() {
        b.switchEnable.isChecked     = Prefs.isEnabled(this)
        b.switchTemp.isChecked       = Prefs.showTemp(this)
        b.switchCurrent.isChecked    = Prefs.showCurrent(this)
        b.switchMemory.isChecked     = Prefs.showMemory(this)
        b.switchNetDown.isChecked    = Prefs.showNetDown(this)
        b.switchFahrenheit.isChecked = Prefs.useFahrenheit(this)

        b.seekTextSize.max      = 12
        b.seekTextSize.progress = Prefs.textSizeSp(this) - 10
        updateTextSizeLabel()

        // 位置输入框
        b.etPosX.setText(Prefs.overlayX(this).toString())
        b.etPosY.setText(Prefs.overlayY(this).toString())

        updateSwitchEnabled(b.switchEnable.isChecked)
    }

    private fun setupListeners() {
        b.switchEnable.setOnCheckedChangeListener { _, c ->
            Prefs.set(this, Prefs.KEY_ENABLED, c)
            updateSwitchEnabled(c)
            if (c) checkPermissionsAndStart() else stopMonitor()
        }

        fun sw(key: String) = { _: Any, c: Boolean ->
            Prefs.set(this, key, c); notifyChanged()
        }
        b.switchTemp.setOnCheckedChangeListener(sw(Prefs.KEY_SHOW_TEMP))
        b.switchCurrent.setOnCheckedChangeListener(sw(Prefs.KEY_SHOW_CURRENT))
        b.switchMemory.setOnCheckedChangeListener(sw(Prefs.KEY_SHOW_MEMORY))
        b.switchNetDown.setOnCheckedChangeListener(sw(Prefs.KEY_SHOW_NET_DOWN))
        b.switchFahrenheit.setOnCheckedChangeListener(sw(Prefs.KEY_TEMP_UNIT))

        // 文字大小
        b.seekTextSize.setOnSeekBarChangeListener(object :
            android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                Prefs.set(this@MainActivity, Prefs.KEY_TEXT_SIZE, p + 10)
                updateTextSizeLabel()
                if (fromUser) notifyChanged()
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })

        // 位置 X
        b.etPosX.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.toIntOrNull() ?: return
                Prefs.set(this@MainActivity, Prefs.KEY_OVERLAY_X, v)
                notifyChanged()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        // 位置 Y
        b.etPosY.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.toIntOrNull() ?: return
                Prefs.set(this@MainActivity, Prefs.KEY_OVERLAY_Y, v)
                notifyChanged()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        // 重置位置
        b.btnResetPos.setOnClickListener {
            Prefs.set(this, Prefs.KEY_OVERLAY_X, 0)
            Prefs.set(this, Prefs.KEY_OVERLAY_Y, 0)
            b.etPosX.setText("0")
            b.etPosY.setText("0")
            notifyChanged()
        }

        // 刷新间隔
        b.radioGroup.setOnCheckedChangeListener { _, id ->
            val ms = when (id) { b.radio1s.id -> 1000; b.radio5s.id -> 5000; else -> 2000 }
            Prefs.set(this, Prefs.KEY_UPDATE_INTERVAL, ms); notifyChanged()
        }
        when (Prefs.updateIntervalMs(this)) {
            1000 -> b.radio1s.isChecked = true
            5000 -> b.radio5s.isChecked = true
            else -> b.radio2s.isChecked = true
        }
    }

    private fun updateTextSizeLabel() {
        b.tvTextSizeLabel.text = "文字大小：${Prefs.textSizeSp(this)}sp"
    }

    private fun updateSwitchEnabled(on: Boolean) {
        listOf(b.switchTemp, b.switchCurrent, b.switchMemory, b.switchNetDown,
            b.switchFahrenheit, b.radio1s, b.radio2s, b.radio5s,
            b.seekTextSize, b.btnResetPos, b.etPosX, b.etPosY).forEach { it.isEnabled = on }
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请授权「显示在其他应用上层」", Toast.LENGTH_LONG).show()
            overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))); return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val p = Manifest.permission.POST_NOTIFICATIONS
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                notifLauncher.launch(p); return
            }
        }
        startMonitor()
    }

    private fun startMonitor() =
        startForegroundService(Intent(this, MonitorService::class.java))

    private fun stopMonitor() =
        startService(Intent(this, MonitorService::class.java).apply { action = MonitorService.ACTION_STOP })

    private fun notifyChanged() {
        if (Prefs.isEnabled(this))
            startService(Intent(this, MonitorService::class.java).apply {
                action = MonitorService.ACTION_SETTINGS_CHANGED })
    }
}
