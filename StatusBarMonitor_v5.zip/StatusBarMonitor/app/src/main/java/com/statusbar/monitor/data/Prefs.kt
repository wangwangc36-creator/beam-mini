package com.statusbar.monitor.data

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "monitor_prefs"

    const val KEY_ENABLED         = "enabled"
    const val KEY_SHOW_TEMP       = "show_temperature"
    const val KEY_SHOW_CURRENT    = "show_current"
    const val KEY_SHOW_MEMORY     = "show_memory"
    const val KEY_SHOW_NET_DOWN   = "show_net_download"
    const val KEY_TEMP_UNIT       = "temp_unit_fahrenheit"
    const val KEY_UPDATE_INTERVAL = "update_interval_ms"
    const val KEY_OVERLAY_X       = "overlay_x"
    const val KEY_OVERLAY_Y       = "overlay_y"
    const val KEY_TEXT_SIZE       = "text_size"          // sp 值，默认 13

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context)       = sp(ctx).getBoolean(KEY_ENABLED, true)
    fun showTemp(ctx: Context)        = sp(ctx).getBoolean(KEY_SHOW_TEMP, true)
    fun showCurrent(ctx: Context)     = sp(ctx).getBoolean(KEY_SHOW_CURRENT, true)
    fun showMemory(ctx: Context)      = sp(ctx).getBoolean(KEY_SHOW_MEMORY, true)
    fun showNetDown(ctx: Context)     = sp(ctx).getBoolean(KEY_SHOW_NET_DOWN, true)
    fun useFahrenheit(ctx: Context)   = sp(ctx).getBoolean(KEY_TEMP_UNIT, false)
    fun updateIntervalMs(ctx: Context)= sp(ctx).getInt(KEY_UPDATE_INTERVAL, 2000)
    fun overlayX(ctx: Context)        = sp(ctx).getInt(KEY_OVERLAY_X, 0)
    fun overlayY(ctx: Context)        = sp(ctx).getInt(KEY_OVERLAY_Y, 0)
    fun textSizeSp(ctx: Context)      = sp(ctx).getInt(KEY_TEXT_SIZE, 13)

    fun set(ctx: Context, key: String, value: Boolean) =
        sp(ctx).edit().putBoolean(key, value).apply()
    fun set(ctx: Context, key: String, value: Int) =
        sp(ctx).edit().putInt(key, value).apply()
}
