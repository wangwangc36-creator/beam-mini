package com.statusbar.monitor.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.statusbar.monitor.data.Prefs
import com.statusbar.monitor.service.MonitorService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            if (Prefs.isEnabled(context)) {
                val svc = Intent(context, MonitorService::class.java)
                context.startForegroundService(svc)
            }
        }
    }
}
